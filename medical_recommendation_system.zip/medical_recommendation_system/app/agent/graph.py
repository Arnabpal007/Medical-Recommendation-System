from langgraph.graph import StateGraph, END
from langchain_core.runnables import RunnableLambda
from app.agent.tools import *
from typing import List, Any
from typing_extensions import TypedDict  # ✅ FIX for Python < 3.12

# --- Define state ---
class AppState(TypedDict):
    text: str
    lang: str
    symptoms: List[str]
    disease: List[dict]  # Dict with name, icd_code
    treatment: List[dict]  # Recommended medicines & advice

# --- Node step functions ---
def detect_language_step(state):
    text = state.get("text", "").strip()
    print(f"[GRAPH] Passing to detect_language_tool: '{text}'")
    return {
        **state,
        **detect_language_tool.invoke({"text": text})
    }

def translate_step(state):
    text = state.get("text", "").strip()
    lang = state.get("lang", "")
    print(f"[GRAPH] Translating text: '{text}' from language: '{lang}'")
    return {
        **state,
        **translate_to_english_tool.invoke({
            "text": text,
            "lang": lang
        })
    }

def extract_step(state):
    text = state.get("text", "").strip()
    print(f"[GRAPH] Extracting symptoms from: '{text}'")
    return {
        **state,
        **extract_symptoms_tool.invoke({"text": text})
    }

def predict_step(state):
    symptoms = state.get("symptoms", [])
    print(f"[GRAPH] Predicting disease from symptoms: {symptoms}")
    return {
        **state,
        **predict_disease_tool.invoke({"symptoms": symptoms})
    }

def treatment_step(state):
    print("[GRAPH] Recommending medicine + advice...")
    symptoms = state.get("symptoms", [])
    diseases = state.get("disease", [])

    enriched = []
    all_meds = []

    # Step 1: Get medicines and advice
    for disease in diseases:
        name = disease.get("name")
        icd = disease.get("icd_code", "")
        if name:
            response = predict_medicine_tool.invoke({
                "disease": name,
                "symptoms": symptoms
            })

            recommended_meds = response.get("recommended_medicines", [])
            all_meds.extend(recommended_meds)

            enriched.append({
                "name": name,
                "icd_code": icd,
                "recommended_medicines": recommended_meds,
                "advice": response.get("advice", "")
            })

    # Step 2: Match with Indian pharma brands (no precautions)
    matched_brands = fuzzy_match_indian_brands.invoke({
        "predicted_meds": all_meds
    })

    # Step 3: Attach matching brands to each disease based on medicine name
    for disease in enriched:
        disease_meds = disease.get("recommended_medicines", [])
        disease["matched_brands"] = [
            b for b in matched_brands if b["input_medicine"] in disease_meds
        ]

    return {**state, "treatment": enriched}


# --- Graph build ---
def build_graph():
    graph = StateGraph(AppState)

    graph.add_node("detect_language", RunnableLambda(detect_language_step))
    graph.add_node("translate", RunnableLambda(translate_step))
    graph.add_node("extract", RunnableLambda(extract_step))
    graph.add_node("predict", RunnableLambda(predict_step))
    graph.add_node("treatment", RunnableLambda(treatment_step))

    def needs_translation(state):
        return "translate" if state.get("lang", "").lower() != "english" else "extract"

    graph.set_entry_point("detect_language")
    graph.add_conditional_edges("detect_language", needs_translation)
    graph.add_edge("translate", "extract")
    graph.add_edge("extract", "predict")
    graph.add_edge("predict", "treatment")
    graph.add_edge("treatment", END)

    return graph.compile()

# --- Compiled workflow ---
workflow = build_graph()
