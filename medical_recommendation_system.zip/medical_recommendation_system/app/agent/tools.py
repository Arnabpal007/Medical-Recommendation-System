import os
import re
import pandas as pd
from dotenv import load_dotenv
from openai import OpenAI
from langchain_core.tools import tool
from rapidfuzz import fuzz, process
from typing import List
from typing_extensions import TypedDict

# Load environment variables
load_dotenv()
client = OpenAI()

# Load Indian pharma dataset
PHARMA_CSV_PATH = "G:/medical_recommendation_system/resources/indian_pharmaceutical_products_clean.csv"
pharma_df = pd.read_csv(PHARMA_CSV_PATH)

# ----------------------------
@tool
def detect_language_tool(text: str) -> dict:
    """Detects the language of a given input text."""
    prompt = f"What language is this?\n\n{text}\n\nRespond only with the language name."
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}]
    )
    language = response.choices[0].message.content.strip()
    return {"lang": language, "text": text}

# ----------------------------
@tool
def translate_to_english_tool(text: str, lang: str) -> dict:
    """Translates the input text to English if it's not already in English."""
    if lang.lower() == "english":
        return {"text": text, "lang": lang}
    prompt = f"Translate this to English:\n\n{text}"
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}]
    )
    translated = response.choices[0].message.content.strip()
    return {"text": translated, "lang": lang}

# ----------------------------
@tool
def extract_symptoms_tool(text: str) -> dict:
    """Extracts a list of symptoms mentioned in the input text."""
    prompt = (
        f"Extract the symptoms mentioned in the following text. "
        f"Return a comma-separated list of symptoms only.\n\n{text}"
    )
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}]
    )
    symptoms_raw = response.choices[0].message.content.strip()
    symptoms = [s.strip() for s in symptoms_raw.split(",") if s.strip()]
    return {"symptoms": symptoms, "text": text}

# ----------------------------
@tool
def predict_disease_tool(symptoms: list[str]) -> dict:
    """Predicts 3 diseases with ICD codes based on a list of symptoms."""
    prompt = (
        f"Given these symptoms: {', '.join(symptoms)}, list exactly 3 possible diseases.\n"
        f"Return only this format:\n"
        f"Name: <Disease Name>\nICD: <ICD Code>\n---\n"
        f"Repeat 3 times. Do not return anything else."
    )
    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}]
    )
    raw = response.choices[0].message.content.strip()
    chunks = re.split(r"(?:---|\n\s*\n)+", raw)
    diseases = []

    for chunk in chunks:
        name_match = re.search(r"Name:\s*(.+)", chunk)
        icd_match = re.search(r"ICD:\s*(.+)", chunk)
        if name_match and icd_match:
            diseases.append({
                "name": name_match.group(1).strip(),
                "icd_code": icd_match.group(1).strip()
            })

    return {"disease": diseases}

# ----------------------------
@tool
def predict_medicine_tool(disease: str, symptoms: list[str]) -> dict:
    """Suggests 2–3 generic medicine names and one general advice."""
    prompt = (
        f"You are a medical assistant in India.\n"
        f"Based on the disease '{disease}' and symptoms: {', '.join(symptoms)}, "
        f"suggest 2–3 generic medicine names (indian pharmaceutical products) (not US brands) commonly available in India. "
        f"Also provide one general piece of advice.\n\n"
        f"Respond ONLY in this format:\n"
        f"Medicines:\n"
        f"- Paracetamol\n"
        f"- Ibuprofen\n"
        f"Advice: Stay hydrated and rest well."
    )

    response = client.chat.completions.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}]
    )
    output = response.choices[0].message.content.strip()

    medicines = []
    advice = ""

    for line in output.splitlines():
        line = line.strip()
        if line.lower().startswith("advice:"):
            advice = line.split(":", 1)[1].strip()
        elif line.startswith("-"):
            name = line[1:].strip()
            if name:
                medicines.append(name)

    return {
        "recommended_medicines": medicines,
        "advice": advice
    }

# ----------------------------
@tool
def fuzzy_match_indian_brands(predicted_meds: list[str]) -> list[dict]:
    """Matches predicted medicines to Indian pharma data using fuzzy logic."""
    matched = []

    for med in predicted_meds:
        # ✅ Extract generic name from parentheses if present
        match = re.match(r".*\((.+?)\)", med)
        if match:
            generic_name = match.group(1).strip()
        else:
            generic_name = med.strip()

        choices = pharma_df["primary_ingredient"].dropna()
        matches = process.extract(
            query=generic_name,
            choices=choices,
            scorer=fuzz.token_sort_ratio,
            limit=1
        )

        if matches and matches[0][1] > 75:
            best_match = matches[0][0]
            row = pharma_df[pharma_df["primary_ingredient"] == best_match].iloc[0]

            matched.append({
                "input_medicine": med,  # keep original for display
                "matched_brand": row["primary_ingredient"],
                "strength": row["primary_strength"],
                "form": row["dosage_form"],
                "manufacturer": row["manufacturer_raw"],
                "price_inr": row["price_inr"],
                "packaging": row["packaging_raw"]
            })

    return matched

