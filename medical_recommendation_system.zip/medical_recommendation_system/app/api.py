from fastapi import APIRouter
from fastapi.responses import HTMLResponse
from app.schemas import SymptomRequest
from app.agent.graph import workflow
from app.agent.tools import fuzzy_match_indian_brands

router = APIRouter()

@router.post("/diagnose")
async def diagnose(request: SymptomRequest):
    input_text = request.input_text.strip()
    print(f">> API Received input: '{input_text}'")

    state = {
        "text": input_text,
        "lang": "",
        "symptoms": [],
        "disease": [],
        "treatment": []
    }

    result = workflow.invoke(state)

    enriched_treatments = []
    for disease_info in result.get("treatment", []):
        meds = disease_info.get("recommended_medicines", [])
        brands = fuzzy_match_indian_brands.invoke({"predicted_meds": meds})  # ✅ fix here

        enriched = {**disease_info, "matched_brands": brands}
        enriched_treatments.append(enriched)

    return {
        "language_detected": result.get("lang"),
        "translated_text": result.get("text", input_text),
        "symptoms": result.get("symptoms"),
        "possible_diseases": enriched_treatments  # ✅ all diseases now
    }


@router.get("/", response_class=HTMLResponse)
async def index():
    with open("static/index.html", encoding="utf-8") as f:
        return f.read()
