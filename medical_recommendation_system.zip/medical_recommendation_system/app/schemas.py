from pydantic import BaseModel

class SymptomRequest(BaseModel):
    input_text: str
